// Load modules
var sqlite3 = require('sqlite3').verbose();
var express = require('express');
var http = require('http');
var path = require("path");
var bodyParser = require('body-parser');
var helmet = require('helmet');
var rateLimit = require("express-rate-limit");

var app = express();
var server = http.createServer(app);

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});


// Create database
var db = new sqlite3.Database('./database/med.db');


app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname,'./public')));
app.use(helmet());
app.use(limiter);

// Run database
db.run('CREATE TABLE IF NOT EXISTS patient(patientId TEXT, name TEXT, address TEXT, contactNo TEXT, medicalHistory TEXT)');


// Load default page
app.get('/', function(req,res){
  res.sendFile(path.join(__dirname,'./public/patient.html'));
});


// Insert
app.post('/add', function(req,res){
  db.serialize(()=>{
    db.run('INSERT INTO patient(patientId,name,address,contactNo,medicalHistory) VALUES(?,?,?,?,?)',
      [req.body.patientId, req.body.name,req.body.address,req.body.contactNo,req.body.medicalHistory], function(err) {
      if (err) {
        return console.log(err.message);
      }
      console.log("New patient has been added");
      res.send("New patient has been added into the database with ID = "
        + req.body.patientId+ "  Name = " + req.body.name + "  Address= "+ req.body.address+ "ContactNo. = "+ req.body.contactNo+ " MedicalHistory="+
        req.body.medicalHistory);
    });
  });
});


// View database
app.post('/view', function(req,res){
  db.serialize(()=>{
    db.each('SELECT patientId PATIENTID, name NAME, address ADDRESS, contactNo CONTACTNO , medicalHistory MEDICALHISTORY FROM patient WHERE patientId =?',
      [req.body.patientId], function(err,row){
      // db.each() is only one which is funtioning
      // while reading data from the DB
      if(err){
        res.send("Error encountered while displaying");
        return console.error(err.message);
      }
      res.send(` ID: ${row.PATIENTID},    Name: ${row.NAME},Address: ${row.ADDRESS} , Contact: ${row.CONTACTNO}  , Medhis: ${row.MEDICALHISTORY}`);
      console.log("Entry displayed successfully");
    });
  });
});


// Update database
app.post('/update', function(req,res){
  db.serialize(()=>{
    db.run('UPDATE patient SET name = ? , address=?, contactNo=?,medicalHistory=? WHERE patientId = ?',
      [req.body.name,req.body.address,req.body.contactNo,req.body.medicalHistory,req.body.patientId], function(err){
      if(err){
        res.send("Error encountered while updating");
        return console.error(err.message);
      }
      res.send("Entry updated successfully");
      console.log("Entry updated successfully");
    });
  });
});


// Delete database
app.post('/delete', function(req,res){
  db.serialize(()=>{
    db.run('DELETE FROM patient WHERE patientId = ?', req.body.patientId, function(err) {
      if (err) {
        res.send("Error encountered while deleting");
        return console.error(err.message);
      }
      res.send("Entry deleted");
      console.log("Entry deleted");
    });
  });
});


// Close database
app.get('/close', function(req,res){
  db.close((err) => {
    if (err) {
      res.send('There is some error in closing the database');
      return console.error(err.message);
    }
    console.log('Closing the database connection.');
    res.send('Database connection successfully closed');
  });
});


//Run server
server.listen(8080,function(){ 
    console.log("Server listening on port: 8080");
});